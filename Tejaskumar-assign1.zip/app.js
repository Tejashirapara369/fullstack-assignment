// Import required modules
const express = require('express');

// Create an instance of the Express application
const app = express();

app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));
// app.get("/", function (req, res) { res.end("Welcome to Home Page") });

// Define the route handlers
app.get('/', (req, res) => {
    res.render('home');
});

app.get('/g', (req, res) => {
    res.render('gLicense');
});

app.get('/g2', (req, res) => {
    res.render('g2License');
});

app.get('/dashboard', (req, res) => {
    res.render('dashboard');
});

app.get('/login', (req, res) => {
    res.render('login');
});


// Start the server
const port = 3000; // You can change the port number if needed
app.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});